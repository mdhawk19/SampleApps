var searchData=
[
  ['before',['before',['../classnapi_1_1_event_on_found_change_data.html#ae7db7166b7cdd311ddd6403f9c4eee0e',1,'napi::EventOnFoundChangeData::before()'],['../classnapi_1_1_event_on_presence_change_data.html#a4a50b3badb69489ca5cb5fbd39212111',1,'napi::EventOnPresenceChangeData::before()']]],
  ['buzz',['Buzz',['../classnapi_1_1_buzz.html',1,'napi']]],
  ['buzz',['buzz',['../classnapi_1_1_buzz_1_1_req.html#ac81040a8e4d045a389681610642255fc',1,'napi::Buzz::Req']]],
  ['buzzkind',['BuzzKind',['../classnapi_1_1_buzz_1_1_req.html#aaa4947f8763d9cc5841ceda62a37f09b',1,'napi::Buzz::Req']]]
];
