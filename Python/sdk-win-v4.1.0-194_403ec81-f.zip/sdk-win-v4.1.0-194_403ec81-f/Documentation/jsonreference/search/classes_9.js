var searchData=
[
  ['totpget',['TOTPGet',['../classnapi_1_1_t_o_t_p_get.html',1,'napi']]],
  ['totprun',['TOTPRun',['../classnapi_1_1_t_o_t_p_run.html',1,'napi']]]
];
