var indexSectionsWithContent =
{
  0: "abcdefghiklnoprstuvy",
  1: "bceiknprst",
  2: "abcdeghknoprstv",
  3: "bcfp",
  4: "adilnpruy",
  5: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables",
  3: "enums",
  4: "enumvalues",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Variables",
  3: "Enumerations",
  4: "Enumerator",
  5: "Pages"
};

