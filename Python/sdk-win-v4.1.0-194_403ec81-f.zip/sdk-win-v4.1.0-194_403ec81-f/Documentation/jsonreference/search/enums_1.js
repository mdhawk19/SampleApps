var searchData=
[
  ['curvetype',['CurveType',['../classnapi_1_1_sign_setup_1_1_req.html#a797baf5c2667f1d098731acd776066f0',1,'napi::SignSetup::Req']]]
];
