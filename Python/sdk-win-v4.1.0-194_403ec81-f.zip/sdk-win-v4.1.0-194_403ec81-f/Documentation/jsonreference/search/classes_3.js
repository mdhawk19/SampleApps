var searchData=
[
  ['infoget',['InfoGet',['../classnapi_1_1_info_get.html',1,'napi']]],
  ['initget',['InitGet',['../classnapi_1_1_init_get.html',1,'napi']]]
];
