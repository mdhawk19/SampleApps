var searchData=
[
  ['notificationget',['NotificationGet',['../classnapi_1_1_notification_get.html',1,'napi']]],
  ['notificationset',['NotificationSet',['../classnapi_1_1_notification_set.html',1,'napi']]]
];
