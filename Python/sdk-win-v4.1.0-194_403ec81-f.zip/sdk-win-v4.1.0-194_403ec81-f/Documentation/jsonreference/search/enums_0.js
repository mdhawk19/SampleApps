var searchData=
[
  ['buzzkind',['BuzzKind',['../classnapi_1_1_buzz_1_1_req.html#aaa4947f8763d9cc5841ceda62a37f09b',1,'napi::Buzz::Req']]]
];
