var searchData=
[
  ['verificationkey',['verificationKey',['../classnapi_1_1_sign_run_1_1_resp.html#adb437ba14cfb54712f6cbfe9bfafd291',1,'napi::SignRun::Resp']]]
];
