var searchData=
[
  ['discovered',['discovered',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95a538416cf3bc59332670af4cae9485ebe',1,'napi::EventOnFoundChangeData']]]
];
