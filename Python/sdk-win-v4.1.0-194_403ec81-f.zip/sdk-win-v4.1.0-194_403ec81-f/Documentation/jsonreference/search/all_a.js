var searchData=
[
  ['likely',['likely',['../classnapi_1_1_event_on_presence_change_data.html#a629f5dc1547bfbc389da8fae14e997c8a2f25409fe57c3dea842828b952101a4d',1,'napi::EventOnPresenceChangeData']]]
];
