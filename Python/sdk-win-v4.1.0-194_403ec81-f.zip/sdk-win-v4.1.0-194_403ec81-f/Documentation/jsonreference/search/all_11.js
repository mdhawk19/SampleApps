var searchData=
[
  ['unclasped',['unclasped',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95acdb818baed0a0c392177c5424d22c3d4',1,'napi::EventOnFoundChangeData']]],
  ['undetected',['undetected',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95a07f48b7c6358be956947cada87fd93f6',1,'napi::EventOnFoundChangeData']]],
  ['unlikely',['unlikely',['../classnapi_1_1_event_on_presence_change_data.html#a629f5dc1547bfbc389da8fae14e997c8a2737fe8dce5cd7d2842da846c89e16b7',1,'napi::EventOnPresenceChangeData']]],
  ['unprovisionable',['unprovisionable',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95a4729e8b0351a8159a40310f9c3369fc2',1,'napi::EventOnFoundChangeData']]]
];
