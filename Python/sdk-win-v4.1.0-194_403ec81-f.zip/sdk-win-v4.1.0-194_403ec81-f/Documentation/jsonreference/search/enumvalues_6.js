var searchData=
[
  ['reject',['reject',['../classnapi_1_1_provision_pattern_1_1_req.html#a2487fa13eeddbaf23037ee8a6bf09c95a6bfaf02d9f3b165809fb7f056665a6bd',1,'napi::ProvisionPattern::Req']]]
];
