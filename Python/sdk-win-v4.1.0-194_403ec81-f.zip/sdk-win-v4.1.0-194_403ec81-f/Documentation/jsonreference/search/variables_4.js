var searchData=
[
  ['err',['err',['../classnapi_1_1_event_on_general_error_data.html#a73d227abe6b40a67814ace4755ece284',1,'napi::EventOnGeneralErrorData']]],
  ['errors',['errors',['../classnapi_1_1_response_envelope.html#a9e816b50373828be819dec182e5c977e',1,'napi::ResponseEnvelope']]],
  ['exchange',['exchange',['../classnapi_1_1_request_envelope.html#a453c31daa79183cea908b22e7a0a3201',1,'napi::RequestEnvelope']]]
];
