var searchData=
[
  ['patternaction',['PatternAction',['../classnapi_1_1_provision_pattern_1_1_req.html#a2487fa13eeddbaf23037ee8a6bf09c95',1,'napi::ProvisionPattern::Req']]],
  ['presencestate',['PresenceState',['../classnapi_1_1_event_on_presence_change_data.html#a629f5dc1547bfbc389da8fae14e997c8',1,'napi::EventOnPresenceChangeData']]]
];
