var searchData=
[
  ['foundstate',['FoundState',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95',1,'napi::EventOnFoundChangeData']]]
];
