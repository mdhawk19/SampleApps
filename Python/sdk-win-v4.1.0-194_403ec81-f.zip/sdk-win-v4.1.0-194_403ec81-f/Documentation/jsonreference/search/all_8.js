var searchData=
[
  ['identified',['identified',['../classnapi_1_1_event_on_found_change_data.html#a3397b0c67303136e6e6138ffea2aca95aa0d5c22a0385001fa00b5a112fcbb79e',1,'napi::EventOnFoundChangeData']]],
  ['infoget',['InfoGet',['../classnapi_1_1_info_get.html',1,'napi']]],
  ['initget',['InitGet',['../classnapi_1_1_init_get.html',1,'napi']]]
];
