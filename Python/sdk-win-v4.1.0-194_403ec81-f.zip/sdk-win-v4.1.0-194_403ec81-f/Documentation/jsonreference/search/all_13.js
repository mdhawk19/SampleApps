var searchData=
[
  ['yes',['yes',['../classnapi_1_1_event_on_presence_change_data.html#a629f5dc1547bfbc389da8fae14e997c8aa6105c0a611b41b08f1209506350279e',1,'napi::EventOnPresenceChangeData']]]
];
