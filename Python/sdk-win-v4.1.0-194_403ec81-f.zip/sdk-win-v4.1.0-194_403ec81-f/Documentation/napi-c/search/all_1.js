var searchData=
[
  ['json_5fnapi_5fx',['JSON_NAPI_X',['../napi_8h.html#ad47fc5756caf8ccb96b00d8c7a52ee1f',1,'napi.h']]]
];
