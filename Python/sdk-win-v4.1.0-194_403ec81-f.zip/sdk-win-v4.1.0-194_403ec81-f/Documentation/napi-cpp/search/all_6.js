var searchData=
[
  ['get',['get',['../namespacenapi.html#a1fe2a324f753c5f69f1420e2833b755c',1,'napi']]],
  ['getoutcome',['GetOutcome',['../namespacenapi.html#a783c17a8a74d96956059b2d8f8823120',1,'napi']]]
];
