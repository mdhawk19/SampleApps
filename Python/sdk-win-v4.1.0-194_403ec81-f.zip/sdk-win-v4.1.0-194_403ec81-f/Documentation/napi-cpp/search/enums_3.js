var searchData=
[
  ['path',['Path',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1',1,'napi']]],
  ['putoutcome',['PutOutcome',['../namespacenapi.html#aa5b14f2ae96c8c68ba31dbc406876ca0',1,'napi']]]
];
