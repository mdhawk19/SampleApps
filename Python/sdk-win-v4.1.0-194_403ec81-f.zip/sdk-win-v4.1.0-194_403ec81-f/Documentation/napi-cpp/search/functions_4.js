var searchData=
[
  ['terminate',['terminate',['../namespacenapi.html#a61b63088411eaf994ffa15db8ba0d58b',1,'napi']]],
  ['translateliteralpath',['translateLiteralPath',['../namespacenapi.html#a918dbe93482714b6544e78c4843f36ca',1,'napi']]],
  ['try_5fget',['try_get',['../namespacenapi.html#a8b51cca989b1201f000630f6990ffeb0',1,'napi']]]
];
