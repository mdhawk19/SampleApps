var searchData=
[
  ['failedtoinit',['failedToInit',['../namespacenapi.html#a9028b9c606685d218f05f1f606439fc8a401a9ca566adae4a351f29e226b2f0cd',1,'napi']]]
];
