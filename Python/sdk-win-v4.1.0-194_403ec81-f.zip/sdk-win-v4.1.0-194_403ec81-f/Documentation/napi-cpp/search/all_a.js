var searchData=
[
  ['missingneaname',['missingNEAName',['../namespacenapi.html#a9028b9c606685d218f05f1f606439fc8abd4ed02d3eb6acf33129796c31b6da53',1,'napi']]]
];
