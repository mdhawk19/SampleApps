var searchData=
[
  ['configoutcome',['ConfigOutcome',['../namespacenapi.html#a9028b9c606685d218f05f1f606439fc8',1,'napi']]]
];
