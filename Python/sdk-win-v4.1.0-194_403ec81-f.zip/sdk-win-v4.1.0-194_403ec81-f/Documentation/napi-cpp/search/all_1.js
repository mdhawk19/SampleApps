var searchData=
[
  ['buffertoosmall',['bufferTooSmall',['../namespacenapi.html#a783c17a8a74d96956059b2d8f8823120ab0b574beff8d4e3dd81aa92192adc676',1,'napi::bufferTooSmall()'],['../namespacenapi.html#a9f76bad5369f08c912debc1968adc040ab0b574beff8d4e3dd81aa92192adc676',1,'napi::bufferTooSmall()']]],
  ['buzz',['Buzz',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1af285bec73b34c6b77026c180aae0e5ba',1,'napi']]]
];
