var searchData=
[
  ['trygetoutcome',['TryGetOutcome',['../namespacenapi.html#a9f76bad5369f08c912debc1968adc040',1,'napi']]]
];
