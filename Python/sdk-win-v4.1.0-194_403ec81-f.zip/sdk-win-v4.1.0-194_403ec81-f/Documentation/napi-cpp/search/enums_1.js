var searchData=
[
  ['getoutcome',['GetOutcome',['../namespacenapi.html#a783c17a8a74d96956059b2d8f8823120',1,'napi']]]
];
