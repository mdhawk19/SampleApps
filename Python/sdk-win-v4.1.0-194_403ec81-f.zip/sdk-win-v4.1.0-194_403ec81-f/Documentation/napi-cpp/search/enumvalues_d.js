var searchData=
[
  ['terminated',['terminated',['../namespacenapi.html#a783c17a8a74d96956059b2d8f8823120add4b8c762f1258f89c4383961c5be121',1,'napi::terminated()'],['../namespacenapi.html#a9f76bad5369f08c912debc1968adc040add4b8c762f1258f89c4383961c5be121',1,'napi::terminated()']]],
  ['totpget',['TOTPGet',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a27e62dc944813770ef1706d266c305b3',1,'napi']]],
  ['totprun',['TOTPRun',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a3aa4faedd9b1d3cda1439798f9903c2b',1,'napi']]]
];
