var searchData=
[
  ['get',['get',['../namespacenapi.html#a1fe2a324f753c5f69f1420e2833b755c',1,'napi']]]
];
