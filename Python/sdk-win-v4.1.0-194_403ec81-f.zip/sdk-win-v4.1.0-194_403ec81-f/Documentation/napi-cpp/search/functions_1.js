var searchData=
[
  ['configure',['configure',['../namespacenapi.html#a9d935c2195fc0700eefbb7175403d9ee',1,'napi']]]
];
