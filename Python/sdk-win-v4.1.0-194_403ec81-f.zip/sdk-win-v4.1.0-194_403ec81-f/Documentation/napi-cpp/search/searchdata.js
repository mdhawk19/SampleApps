var indexSectionsWithContent =
{
  0: "abcdefgiklmnoprstuv",
  1: "n",
  2: "acgpt",
  3: "cglpt",
  4: "bcdefikmnoprstuv",
  5: "n"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions",
  3: "enums",
  4: "enumvalues",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Functions",
  3: "Enumerations",
  4: "Enumerator",
  5: "Pages"
};

