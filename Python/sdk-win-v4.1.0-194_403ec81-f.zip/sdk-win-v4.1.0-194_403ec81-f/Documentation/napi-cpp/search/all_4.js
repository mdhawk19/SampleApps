var searchData=
[
  ['error',['error',['../namespacenapi.html#a9028b9c606685d218f05f1f606439fc8acb5e100e5a9a3e7f6d1fd97512215282',1,'napi::error()'],['../namespacenapi.html#a783c17a8a74d96956059b2d8f8823120acb5e100e5a9a3e7f6d1fd97512215282',1,'napi::error()'],['../namespacenapi.html#a9f76bad5369f08c912debc1968adc040acb5e100e5a9a3e7f6d1fd97512215282',1,'napi::error()'],['../namespacenapi.html#aa5b14f2ae96c8c68ba31dbc406876ca0acb5e100e5a9a3e7f6d1fd97512215282',1,'napi::error()']]],
  ['eventonfoundchangedata',['EventOnFoundChangeData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1aded28e8d460b48f9f0b2f67c7f610e93',1,'napi']]],
  ['eventongeneralerrordata',['EventOnGeneralErrorData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a4a06567a10d6565799c8c1f8b44277cb',1,'napi']]],
  ['eventonledpatternchangedata',['EventOnLEDPatternChangeData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a642bbc3c16e9805b6165a1d08aaebe5a',1,'napi']]],
  ['eventonpresencechangedata',['EventOnPresenceChangeData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a3708926772e70f6db709843df8d168e5',1,'napi']]],
  ['eventonprovisioneddata',['EventOnProvisionedData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a9aafe9772f164b1c336091c8f9f0d596',1,'napi']]],
  ['eventonprovisionschangeddata',['EventOnProvisionsChangedData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1ac9c56f649b2ec9a1d46d8430c18d21af',1,'napi']]],
  ['eventranoncedata',['EventRANonceData',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1a86e96fcf418ba124e6e4651112844929',1,'napi']]]
];
