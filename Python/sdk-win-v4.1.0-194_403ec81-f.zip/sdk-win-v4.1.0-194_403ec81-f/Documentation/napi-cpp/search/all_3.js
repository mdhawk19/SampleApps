var searchData=
[
  ['debug',['debug',['../namespacenapi.html#a176f091bfe32383a1ef1a6e1cbd8235baad42f6697b035b7580e4fef93be20b4d',1,'napi']]]
];
