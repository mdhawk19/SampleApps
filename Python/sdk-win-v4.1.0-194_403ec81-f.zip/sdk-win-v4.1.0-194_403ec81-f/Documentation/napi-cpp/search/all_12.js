var searchData=
[
  ['verbose',['verbose',['../namespacenapi.html#a176f091bfe32383a1ef1a6e1cbd8235ba2c7aea4237e25b4f8ee3b0bf77d6fed0',1,'napi']]]
];
