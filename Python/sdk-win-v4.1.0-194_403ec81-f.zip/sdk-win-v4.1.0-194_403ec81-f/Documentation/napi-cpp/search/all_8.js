var searchData=
[
  ['keydelete',['KeyDelete',['../namespacenapi.html#a63646fa6ca4a449649af089355a9baf1aa010fe8d2173f391a010aef3478c2372',1,'napi']]]
];
